/**
 * src/services/maintenance/PredictiveRulEngine.ts
 * 
 * Moteur Déterministe de Calcul du RUL (Remaining Useful Life) & Détection Proactive 4.0
 * Conforme à la Master Spec v2.0 (OEM-First, Modèles Physiques, Lois d'Arrhenius, Archard, Weibull & Scania APS).
 * 
 * Exporté depuis @docteurflotte/contracts pour partage multi-paquet.
 */

export * from '@docteurflotte/contracts';
