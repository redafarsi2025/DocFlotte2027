import { redirect } from 'next/navigation';

export default function HardwareRedirectPage() {
  redirect('/telematics/hardware');
}
