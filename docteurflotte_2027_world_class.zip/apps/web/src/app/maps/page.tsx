import { redirect } from 'next/navigation';

export default function MapsRedirectPage() {
  redirect('/live-cockpit');
}

