import { CalculationProofData } from '../components/decisions/CalculationProofModal';
import { DigitalTwinOrganStatus, DigitalTwinAsset } from '@docteurflotte/contracts';
import { DispatchDecisionResult } from './api-fleet-intelligence';

export class CalculationProofBuilder {
  /**
   * Preuve de calcul pour un arbitrage de maintenance économique
   */
  static buildMaintenanceDecisionProof(dec: {
    title: string;
    assetName: string;
    assetCode: string;
    estimatedActionCost: number;
    costInactionRisk: number;
    netExpectedSavings: number;
    explanationDossier?: any;
    ruleId: string;
  }): CalculationProofData {
    const actionCost = Number(dec.estimatedActionCost);
    const inactionRisk = Number(dec.costInactionRisk);
    const netSavings = Number(dec.netExpectedSavings);
    const hypotheses = dec.explanationDossier?.economicHypotheses || {};
    const inputMetrics = dec.explanationDossier?.inputMetrics || {};

    const laborHours = hypotheses.estimatedLaborHours || 4;
    const laborRate = hypotheses.hourlyLaborRateApplied || 1500;
    const partsCost = hypotheses.estimatedPartsCost || Math.round(actionCost - laborHours * laborRate);
    const inactionMultiplier = hypotheses.inactionMultiplier || 3.5;
    const towingCost = hypotheses.towingCost || 45000;
    const directFailureRisk = Math.round(partsCost * inactionMultiplier);
    const missionLossRisk = inactionRisk - directFailureRisk - towingCost;

    return {
      title: `Preuve de l'Arbitrage Économique & Coût d'Inaction`,
      decisionOrMetricName: `${dec.assetName} (${dec.assetCode}) — ${dec.title}`,
      category: 'FINANCIAL',
      ruleId: dec.ruleId || 'RULE-DEC-001',
      legalOrOemReference: 'MASTER_SPEC v2.0 §5.1 (Arbitrage Coût d\'Action vs Risque d\'Inaction)',
      deterministicFormula: 'Économie Nette = Risque d\'Inaction - Coût d\'Action Immédiate',
      formulaExplanation:
        'Le coût d\'inaction modélise la cascade de défaillance : aggravation des dommages matériels (facteur d\'amplification K_inaction), frais de remorquage d\'urgence sur route algérienne et perte d\'exploitation journalière.',
      variables: [
        {
          name: 'Coût Pièces Détachées OEM',
          symbol: 'C_pièces',
          value: partsCost.toLocaleString('fr-DZ'),
          unit: 'DA',
          source: 'Catalogue RMI & Stock Magasin',
        },
        {
          name: 'Main d\'Œuvre Atelier Qualifié',
          symbol: 'T_MO × H',
          value: `${laborHours} h × ${laborRate} DA/h = ${(laborHours * laborRate).toLocaleString('fr-DZ')}`,
          unit: 'DA',
          source: 'Barème Atelier Conventionné',
        },
        {
          name: 'Multiplicateur d\'Aggravation Casse',
          symbol: 'K_inaction',
          value: `x${inactionMultiplier}`,
          source: 'Matrice de criticité défaillance (MASTER_SPEC)',
        },
        {
          name: 'Forfait Remorquage Lourd Wilaya',
          symbol: 'C_remorque',
          value: towingCost.toLocaleString('fr-DZ'),
          unit: 'DA',
          source: 'Tarif Réseau Dépannage Algérie',
        },
        {
          name: 'Compteur Actuel vs Échéance',
          symbol: 'Δ_retard',
          value: inputMetrics.deltaOverdue ? `+${inputMetrics.deltaOverdue} km` : 'Échéance dépassée',
          source: 'Télématique Traccar CAN / J1939',
        },
      ],
      steps: [
        {
          stepNumber: 1,
          description: 'Calcul du Coût d\'Action Immédiate en Atelier',
          formula: 'Coût_Action = C_pièces + (Heures × Taux_Horaire)',
          calculation: `${partsCost.toLocaleString('fr-DZ')} DA + (${laborHours} h × ${laborRate} DA/h)`,
          intermediateResult: `${actionCost.toLocaleString('fr-DZ')} DA`,
        },
        {
          stepNumber: 2,
          description: 'Calcul du Risque Financier d\'Inaction (Casse en mission)',
          formula: 'Risque_Inaction = (C_pièces × K_inaction) + C_remorquage + Perte_Exploitation',
          calculation: `(${partsCost.toLocaleString('fr-DZ')} × ${inactionMultiplier}) + ${towingCost.toLocaleString('fr-DZ')} + ${Math.max(0, missionLossRisk).toLocaleString('fr-DZ')}`,
          intermediateResult: `${inactionRisk.toLocaleString('fr-DZ')} DA`,
        },
        {
          stepNumber: 3,
          description: 'Calcul de l\'Économie Nette Garantie (ROI SAD)',
          formula: 'Économie_Nette = Risque_Inaction - Coût_Action',
          calculation: `${inactionRisk.toLocaleString('fr-DZ')} DA - ${actionCost.toLocaleString('fr-DZ')} DA`,
          intermediateResult: `+${netSavings.toLocaleString('fr-DZ')} DA`,
        },
      ],
      finalResult: {
        label: 'Arbitrage Rentable',
        value: `+${netSavings.toLocaleString('fr-DZ')}`,
        unit: 'DA',
        conclusion: `Intervenir immédiatement génère un gain net direct de ${netSavings.toLocaleString('fr-DZ')} DA en prévenant un arrêt forcé de l'actif.`,
      },
    };
  }

  /**
   * Preuve de calcul pour le Moteur Décisionnel de Dispatch ADS (4 Portes & TOPSIS)
   */
  static buildDispatchProof(result: DispatchDecisionResult): CalculationProofData {
    return {
      title: 'Preuve de l\'Arbre de Décision ADS (4 Portes & Matrice TOPSIS)',
      decisionOrMetricName: `Affectation Mission — Décision : ${result.decisionOutcome}`,
      category: 'DISPATCH_TOPSIS',
      ruleId: 'GATE-ADS-005',
      legalOrOemReference: 'Loi 01-14 / Décret 03-223 (ENACTA) • Arrêté Wilaya 16 • TOPSIS ISO/IEC',
      deterministicFormula: 'Décision = Porte_1(Conformité) ∧ Porte_2(Rocades) ∧ Porte_3(VHI ≥ 65) ∧ Porte_4(TOPSIS)',
      formulaExplanation:
        'L\'ADS évalue séquentiellement 4 barrières de sécurité inviolables (Fail-Closed). Si l\'actif initial échoue à une porte, la matrice TOPSIS recherche déterministement le meilleur véhicule alternatif de même catégorie.',
      variables: [
        {
          name: 'Porte 1 — Statut Contrôle Technique',
          symbol: 'ENACTA',
          value: result.violationsDetected.some((v) => v.code.includes('ENACTA')) ? 'ÉCHU (Bloquant)' : 'VALIDE',
          source: 'Registre Légal ENACTA / Loi 01-14',
        },
        {
          name: 'Porte 2 — Restrictions Horaires Wilaya',
          symbol: 'Arrêté_16',
          value: result.violationsDetected.some((v) => v.code.includes('WILAYA')) ? 'INTERDICTION (07h-20h)' : 'AUTORISÉ',
          source: 'Arrêté Wilaya d\'Alger (Rocades Sud/Nord)',
        },
        {
          name: 'Porte 3 — Indice de Santé Véhicule',
          symbol: 'VHI_Min',
          value: result.violationsDetected.some((v) => v.code.includes('VHI')) ? 'CRITIQUE (< 65)' : 'NOMINAL (≥ 65)',
          source: 'Modèle Physique 5 Organes',
        },
        {
          name: 'Porte 4 — Actif Substitué Optimal',
          symbol: 'Candidat_TOPSIS',
          value: result.assignedRegistrationPlate || result.assignedVehicleId || 'Aucun actif disponible',
          source: 'Algorithme TOPSIS (Distance, Charge, Conso)',
        },
      ],
      steps: [
        {
          stepNumber: 1,
          description: 'Évaluation de la Porte 1 (Légalité Administrative & ENACTA)',
          formula: 'P1 = (Date_Validité ≥ Date_Mission) ∧ (Assurance == Active)',
          calculation: result.violationsDetected.some((v) => v.code.includes('ENACTA'))
            ? 'Date de visite technique antérieure à la date de mission -> ÉCHEC PORTE 1'
            : 'Documents à jour -> PORTE 1 VALIDÉE',
          intermediateResult: result.violationsDetected.some((v) => v.code.includes('ENACTA')) ? 'REJET P1' : 'SUCCÈS P1',
        },
        {
          stepNumber: 2,
          description: 'Évaluation de la Porte 2 (Réglementation Wilaya et Itinéraire)',
          formula: 'P2 = ¬(PTAC > 3.5t ∧ Heure ∈ [07h, 20h] ∧ Rocade_Alger)',
          calculation: result.violationsDetected.some((v) => v.code.includes('WILAYA'))
            ? 'Véhicule lourd en transit Alger pendant la plage d\'interdiction -> DÉVIATION / AJUSTEMENT'
            : 'Itinéraire conforme -> PORTE 2 VALIDÉE',
          intermediateResult: result.violationsDetected.some((v) => v.code.includes('WILAYA')) ? 'AJUSTEMENT REQUIS' : 'SUCCÈS P2',
        },
        {
          stepNumber: 3,
          description: 'Évaluation de la Porte 3 & 4 (Santé VHI & Classement TOPSIS)',
          formula: 'Score_TOPSIS = D_minus / (D_plus + D_minus)',
          calculation: result.assignedRegistrationPlate
            ? `Véhicule alternatif sélectionné : ${result.assignedRegistrationPlate} avec meilleur ratio charge/distance`
            : 'Aucun véhicule alternatif conforme trouvé',
          intermediateResult: result.assignedRegistrationPlate ? 'SUBSTITUTION VALIDÉE' : 'MISSION REJETÉE',
        },
      ],
      finalResult: {
        label: 'Statut Exécutif ADS',
        value: result.decisionOutcome,
        conclusion: `Résultat calculé en temps réel sans intervention humaine arbitraire, garantissant zéro amende et zéro immobilisation.`,
      },
    };
  }

  /**
   * Preuve de calcul pour le Score VHI Global (Jumeau Numérique)
   */
  static buildVhiScoreProof(twin: DigitalTwinAsset): CalculationProofData {
    const oil = twin.organs.find((o) => o.organ === 'ENGINE_OIL')?.healthPercent || 70;
    const battery = twin.organs.find((o) => o.organ === 'BATTERY_CRANKING')?.healthPercent || 80;
    const brakes = twin.organs.find((o) => o.organ === 'BRAKE_PADS')?.healthPercent || 60;
    const cooling = twin.organs.find((o) => o.organ === 'COOLING_SYSTEM')?.healthPercent || 85;
    const fap = twin.organs.find((o) => o.organ === 'DPF_FILTER')?.healthPercent || 75;

    return {
      title: 'Preuve de Calcul du Score de Santé Globale VHI (0-100)',
      decisionOrMetricName: `${twin.assetName} (${twin.assetCode}) — VHI Global`,
      category: 'VHI',
      ruleId: 'ALGO-PHYS-VHI-01',
      legalOrOemReference: 'MASTER_SPEC v2.0 §4.1 (Modèle Physique Intégré VHI)',
      deterministicFormula: 'VHI = (0.25 × Huile) + (0.20 × Batterie) + (0.20 × Freins) + (0.20 × Refroidissement) + (0.15 × FAP)',
      formulaExplanation:
        'Le Vehicle Health Index (VHI) ne fait aucune moyenne naïve : chaque organe d\'usure est modélisé par son équation physique dédiée puis agrégé selon sa criticité opérationnelle.',
      variables: [
        { name: 'Santé Huile (Arrhenius)', symbol: 'S_huile', value: oil, unit: '%', source: 'Loi cinétique d\'Arrhenius (Ea/R=6500K)' },
        { name: 'Santé Batterie (CVHI)', symbol: 'S_bat', value: battery, unit: '%', source: 'Tension résiduelle au pic démarreur' },
        { name: 'Santé Freins (Archard)', symbol: 'S_freins', value: brakes, unit: '%', source: 'Épaisseur garniture mm / Loi d\'Archard' },
        { name: 'Santé Refroidissement', symbol: 'S_refroid', value: cooling, unit: '%', source: 'Gradient thermique différentiel EWMA' },
        { name: 'Santé FAP (Suie)', symbol: 'S_fap', value: fap, unit: '%', source: 'Bilan massique & contre-pression mbar' },
      ],
      steps: [
        {
          stepNumber: 1,
          description: 'Pondération Huile Moteur & Viscosité (Poids 25%)',
          formula: '0.25 × S_huile',
          calculation: `0.25 × ${oil}%`,
          intermediateResult: `${(0.25 * oil).toFixed(1)} pts`,
        },
        {
          stepNumber: 2,
          description: 'Pondération Batterie & Démarreur (Poids 20%)',
          formula: '0.20 × S_bat',
          calculation: `0.20 × ${battery}%`,
          intermediateResult: `${(0.2 * battery).toFixed(1)} pts`,
        },
        {
          stepNumber: 3,
          description: 'Pondération Freinage & Refroidissement (Poids 20% + 20%)',
          formula: '(0.20 × S_freins) + (0.20 × S_refroid)',
          calculation: `(0.20 × ${brakes}%) + (0.20 × ${cooling}%)`,
          intermediateResult: `${(0.2 * brakes + 0.2 * cooling).toFixed(1)} pts`,
        },
        {
          stepNumber: 4,
          description: 'Pondération Filtre à Particules (Poids 15%)',
          formula: '0.15 × S_fap',
          calculation: `0.15 × ${fap}%`,
          intermediateResult: `${(0.15 * fap).toFixed(1)} pts`,
        },
      ],
      finalResult: {
        label: 'Score Synthétique VHI',
        value: `${twin.currentVhi}`,
        unit: '/ 100',
        conclusion: `Score calculé à ${twin.currentVhi}/100. ${twin.currentVhi >= 70 ? 'Véhicule en excellente condition opérationnelle.' : twin.currentVhi >= 50 ? 'Vigilance et intervention préventive requises.' : 'Alerte critique : risque d\'immobilisation.'}`,
      },
    };
  }

  /**
   * Preuve de calcul pour un organe physique spécifique (Huile, Freins, Batterie, etc.)
   */
  static buildOrganProof(organ: DigitalTwinOrganStatus, twin: DigitalTwinAsset): CalculationProofData {
    switch (organ.organ) {
      case 'ENGINE_OIL':
        return {
          title: 'Preuve de la Loi Cinétique d\'Arrhenius (Huile & Viscosité)',
          decisionOrMetricName: `Huile Moteur — RUL : ${organ.remainingUsefulLifeValue.toLocaleString()} ${organ.remainingUsefulLifeUnit}`,
          category: 'PHYSICS_RUL',
          ruleId: 'ALGO-ARRHENIUS-01',
          legalOrOemReference: 'MASTER_SPEC v2.0 §4.2 (Loi d\'Arrhenius Ea/R = 6500 K)',
          deterministicFormula: 'Facteur_Dégradation = 1.20 × K_climat × K_conduite',
          formulaExplanation:
            'L\'oxydation et le cisaillement de l\'huile s\'accélèrent exponentiellement avec la température du carter et les poussières de silice. Le RUL kilométrique est divisé par le facteur combiné.',
          variables: [
            { name: 'Facteur Sévérité Climatique', symbol: 'K_clim', value: twin.climateSeverityFactor, source: 'Wilaya (Température & Poussières)' },
            { name: 'Facteur Agressivité Conduite', symbol: 'K_driver', value: twin.driverAggressivenessScore, source: 'CANbus (Sur-régimes & Accélérations)' },
            { name: 'Odomètre Actuel', symbol: 'Km_réel', value: twin.currentOdometerKm.toLocaleString(), unit: 'km', source: 'Compteur Traccar' },
            { name: 'Intervalle Constructeur RMI', symbol: 'Interv_OEM', value: '15 000', unit: 'km', source: 'Spécification OEM' },
          ],
          steps: [
            {
              stepNumber: 1,
              description: 'Calcul du Facteur de Contrainte Combiné',
              formula: 'Facteur_Total = 1.20 × K_clim × K_driver',
              calculation: `1.20 × ${twin.climateSeverityFactor} × ${twin.driverAggressivenessScore}`,
              intermediateResult: `x${(1.2 * twin.climateSeverityFactor * twin.driverAggressivenessScore).toFixed(2)}`,
            },
            {
              stepNumber: 2,
              description: 'Kilomètres Théoriques Restants selon Cycle',
              formula: 'Km_Bruts = 15 000 - (Odomètre mod 15 000)',
              calculation: `15 000 - (${twin.currentOdometerKm} mod 15 000)`,
              intermediateResult: `${Math.round(15000 - (twin.currentOdometerKm % 15000))} km`,
            },
            {
              stepNumber: 3,
              description: 'Application de la Loi d\'Arrhenius pour le RUL Réel',
              formula: 'RUL_Réel = Km_Bruts / Facteur_Total',
              calculation: `${Math.round(15000 - (twin.currentOdometerKm % 15000))} / ${(1.2 * twin.climateSeverityFactor * twin.driverAggressivenessScore).toFixed(2)}`,
              intermediateResult: `${organ.remainingUsefulLifeValue.toLocaleString()} km`,
            },
          ],
          finalResult: {
            label: 'Durée de Vie Résiduelle Réelle',
            value: `${organ.remainingUsefulLifeValue.toLocaleString()}`,
            unit: 'km',
            conclusion: `Vidange et remplacement filtre requis dans ${organ.remainingUsefulLifeValue.toLocaleString()} km pour éviter le cisaillement du film lubrifiant.`,
          },
        };

      case 'BRAKE_PADS':
        const padThickness = parseFloat(String(organ.observedMetrics[0]?.value || '4.2'));
        const usefulPad = Math.max(0, padThickness - 3.0);

        return {
          title: 'Preuve de la Loi Tribologique d\'Archard (Usure des Plaquettes)',
          decisionOrMetricName: `Freinage & Garnitures — RUL : ${organ.remainingUsefulLifeValue.toLocaleString()} ${organ.remainingUsefulLifeUnit}`,
          category: 'PHYSICS_RUL',
          ruleId: 'ALGO-ARCHARD-03',
          legalOrOemReference: 'MASTER_SPEC v2.0 §4.4 (Loi d\'Archard W = K × 1/2 m Δv²)',
          deterministicFormula: 'Épaisseur(mm) = 12.0 - ((Km mod 40 000) / 4 000) × K_stress',
          formulaExplanation:
            'L\'usure surfacique des garnitures de friction dépend directement de l\'énergie cinétique dissipée à chaque décélération. Le seuil de sécurité constructeur minimal est fixé à 3.0 mm.',
          variables: [
            { name: 'Épaisseur Initiale Plaquette Neuve', symbol: 'E_neuve', value: '12.0', unit: 'mm', source: 'Cahier des charges OEM' },
            { name: 'Seuil Critique Constructeur', symbol: 'E_min', value: '3.0', unit: 'mm', source: 'Norme Sécurité ENACTA' },
            { name: 'Épaisseur Actuelle Mesurée', symbol: 'E_actuelle', value: organ.observedMetrics[0]?.value || '4.2 mm', source: 'Calcul d\'usure cinétique CAN' },
            { name: 'Agressivité de Freinage', symbol: 'K_driver', value: twin.driverAggressivenessScore, source: 'Accéléromètre 3-axes Traccar' },
          ],
          steps: [
            {
              stepNumber: 1,
              description: 'Calcul de l\'Épaisseur Résiduelle de Garniture',
              formula: 'Garniture_Utile = Épaisseur_Actuelle - Seuil_Sécurité (3.0 mm)',
              calculation: `${padThickness.toFixed(1)} mm - 3.0 mm`,
              intermediateResult: `${usefulPad.toFixed(1)} mm`,
            },
            {
              stepNumber: 2,
              description: 'Conversion en Kilomètres Résiduels (RUL)',
              formula: 'RUL_km = Garniture_Utile × 4 500 km/mm / K_driver',
              calculation: `${usefulPad.toFixed(1)} mm × 4 500 / ${twin.driverAggressivenessScore}`,
              intermediateResult: `${organ.remainingUsefulLifeValue.toLocaleString()} km`,
            },
          ],
          finalResult: {
            label: 'RUL Freinage',
            value: `${organ.remainingUsefulLifeValue.toLocaleString()}`,
            unit: 'km',
            conclusion: `Remplacement impératif avant les ${organ.remainingUsefulLifeValue.toLocaleString()} prochains km pour préserver les disques et la conformité au contrôle technique.`,
          },
        };

      default:
        return {
          title: `Preuve du Modèle Physique : ${organ.name}`,
          decisionOrMetricName: `${organ.name} — Santé : ${organ.healthPercent}%`,
          category: 'PHYSICS_RUL',
          ruleId: organ.physicsAlgorithm,
          legalOrOemReference: 'MASTER_SPEC v2.0 (Spécifications OEM)',
          deterministicFormula: organ.physicsAlgorithm,
          formulaExplanation: organ.explanation,
          variables: organ.observedMetrics.map((m) => ({
            name: m.label,
            value: m.value,
            source: `Télématique IoT (Seuil: ${m.threshold})`,
          })),
          steps: [
            {
              stepNumber: 1,
              description: 'Acquisition des flux télématiques Traccar / CAN',
              formula: 'Mesure directe du capteur',
              calculation: `Donnée observée : ${organ.observedMetrics[0]?.value || 'Nominale'}`,
              intermediateResult: 'Validé',
            },
            {
              stepNumber: 2,
              description: 'Comparaison au seuil de sécurité nominal',
              formula: 'Conformité = Mesure vs Seuil',
              calculation: `${organ.observedMetrics[0]?.value || 'Valeur'} vs Seuil ${organ.observedMetrics[0]?.threshold || '< Seuil'}`,
              intermediateResult: `${organ.status}`,
            },
          ],
          finalResult: {
            label: 'Durée Résiduelle',
            value: `${organ.remainingUsefulLifeValue}`,
            unit: organ.remainingUsefulLifeUnit,
            conclusion: organ.explanation,
          },
        };
    }
  }
}
