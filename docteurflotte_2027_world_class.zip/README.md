# DocteurFlotte — Monorepo Socle MVP

Plateforme SaaS décisionnelle, contrôle de gestion et maintenance proactive/préventive/prédictive des actifs opérationnels (véhicules légers, poids lourds, engins de chantier, équipements industriels).

Conforme au contrat maître d'architecture : [`AGENTS.md`](./AGENTS.md).

---

## 1. Structure du Répertoire

```text
docteurflotte_2027/
├── AGENTS.md               # Contrat maître d'exploitation et règles produit
├── apps/
│   ├── api/                # API NestJS modulaire (Port 3001)
│   └── web/                # Application Web Next.js App Router (Port 3000)
├── packages/
│   └── contracts/          # Contrats TypeScript, types de santé et domaines partagés
├── infra/
│   └── compose.yaml        # PostgreSQL 16 & Redis 7 (Ports 5434 & 6380)
├── docs/
│   └── agent-reports/      # Rapports d'avancement vérifiés par les agents
├── .env.example            # Gabarit de configuration d'environnement documenté
├── turbo.json              # Orchestration Turborepo
└── pnpm-workspace.yaml     # Gestionnaire d'espace de travail pnpm
```

---

## 2. Ports et Conflits Réseau Hôte

Afin de préserver les autres environnements de développement et conteneurs existants sur la machine hôte :

| Service | Port Interne | Port Hôte Retenu | Variable d'environnement |
| :--- | :--- | :--- | :--- |
| **PostgreSQL** | `5432` | **`5434`** *(5432 & 5433 étant occupés)* | `POSTGRES_PORT` |
| **Redis** | `6379` | **`6380`** *(6379 étant occupé)* | `REDIS_PORT` |
| **API NestJS** | `3001` | **`3001`** | `PORT` |
| **Web Next.js** | `3000` | **`3000`** | `WEB_PORT` |

---

## 3. Démarrage et Commandes

### Installation des dépendances
```bash
pnpm install
```

### Infrastructure Locale (Docker Compose)
```bash
docker compose -f infra/compose.yaml up -d
```

### Vérifications et Contrôles
```bash
# Vérification des types
pnpm typecheck

# Tests automatisés
pnpm test

# Build de tous les paquets et applications
pnpm build

# Démarrage en mode développement
pnpm dev
```

---

## 4. Endpoints de Contrôle Technique (API)

- `GET http://localhost:3001/health` : Contrôle de vie immédiat (statut, version, uptime).
- `GET http://localhost:3001/ready` : Contrôle d'état des dépendances opérationnelles (PostgreSQL, Redis).
